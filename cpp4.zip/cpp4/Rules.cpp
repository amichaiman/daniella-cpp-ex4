/*
 * Rules.cpp
 *
 *  Created on: Dec 9, 2018
 *      Author: test
 */

#include "Rules.h"

