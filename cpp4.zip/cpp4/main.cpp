#include <iostream>
#include <cstdlib>
#include "Simulation.h"

using namespace std;

inline void invalidInput(int exitCode) {
    cerr << "ERROR: Invalid input." << endl;
    exit(exitCode);
}
int main(int argc, char** argv) {
    if (argc != 3){
        invalidInput(1);
    }

    Simulation simulation; // create new Simulation instance
	
    if (!simulation.config(argv[1])){ //if config did not succeed, show error massage
        invalidInput(2);
    }
	
    if (!simulation.init(argv[2])){ //if init did not succeed, show error massage
        invalidInput(3);
    }
	cout<<":0"<<endl;
    simulation.run(); //if everything is ok at this point, go to run function
	cout<<"::::"<<endl;
    return 0;
}
