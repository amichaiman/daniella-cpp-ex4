/*
 * TreeNode.h
 *
 *  Created on: Dec 22, 2018
 *      Author: test
 */

#ifndef TREENODE_H_
#define TREENODE_H_


template<class T>
class TreeNode{
private:
	TreeNode<T>* *parent, leftChild, *rightChild; // pointers to left and right children, and to parent of current node
	T key; // value of node. pointer instead of a T type object allows inherited objects to be a part of the tree
	int nodeID; //id of node
public:
	TreeNode():parent(0), leftChild(0),rightChild(0), nodeID(0),key(T()){} //default c'tor

	TreeNode(const T& key, int nodeID):parent(0), leftChild(0),rightChild(0){ //c'tor
		this->key=key;
		this->nodeID=nodeID;
	}
	TreeNode(const TreeNode<T>& rhs){ // copy c'tor
		if (rhs.getLeftChild()){
			leftChild = new TreeNode<T>(*rhs.getLeftChild());
			leftChild->setParent(this);
		}
		if(rhs.getRightChild()){
			rightChild = new TreeNode<T>(*rhs.getRightChild());
			rightChild->setParent(this);
		}
		setParent(NULL);
		key=rhs.key;
		nodeID=rhs.nodeID;
	}

	TreeNode<T>& operator=(const TreeNode<T>& rhs){ //	=operator *****COME BACK HERE*****
		if (this!= rhs){
			// =rhs.;
		}
		return this;
	}
	void setKey(T Key){this->key=key;}
	void setnodeID(int nodeID){this->nodeID=nodeID;}

	void setLeftChild(TreeNode<T> *leftChild){
		if (this->leftChild)
			delete leftChild;
		this->leftChild=leftChild;}
	void setRightChild(TreeNode<T> *rightChild){
		if (this->rightChild)
					delete rightChild;
		this->rightChild=rightChild;}
	void setParent(TreeNode<T> *parent){
		if (this->parent){
			if(this==(parent->getLeftChild()))
				parent->setLeftChild(NULL);
			else
				parent->setRightChild(NULL);
			delete parent;
		}
		this->parent=parent;}
	TreeNode<T> * getLeftChild()const{return leftChild;}			//get left
	TreeNode<T> * getRightChild()const{return rightChild;} 		//get right
	TreeNode<T> * getParent()const{return parent;} 		// get parent
	const T& getKey()const {return key;}			//get key data
	int getnodeID(){return nodeID;}   	//getID
	~TreeNode(){delete leftChild; delete rightChild;} //d'tor

};




#endif /* TREENODE_H_ */
