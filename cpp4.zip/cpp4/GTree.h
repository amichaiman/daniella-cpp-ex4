/*
 * GTree.h
 *
 *  Created on: Dec 22, 2018
 *      Author: test
 */

#ifndef GTREE_H_
#define GTREE_H_
#include <iostream>
#include "TreeNode.h"
using namespace std;

template <class T>
class GTree {
private:
	TreeNode<T>* root;
	int numOfNodes(TreeNode<T> *root);


public:
	GTree();  //  default c'tor
	GTree(const GTree<T>& rhs);   //  copy c'tor
	GTree& operator=(const GTree<T>& rhs); //  =operator
	void insert(const T& key); //add element
	void clear(); //clear tree
	TreeNode<T>* search(TreeNode<T>* root, const T & key)const ; //find element
	TreeNode<T>* min(TreeNode<T>* root)const; //go to minimum
	TreeNode<T>* max(TreeNode<T>* root)const; // go to maximum
	void remove(const T& key,TreeNode<T>* node);
	void print(TreeNode<T>* root)const; //prints the tree
	int whatIsTheNumOfNodes();
	virtual ~GTree(){clear(root);} //d'tor

};
template<class T>
void GTree<T>::insert(const T& key){
	if(root==NULL){ // means that its the first one to go in!
		root=new TreeNode<T>();
		root->setKey(key);
		return;
	}
	TreeNode<T> *temp = root; // temporary node
	while(1){
		if (key<temp->getKey()){
			if (temp->getLeftChild()==NULL){ //if i should go left and its empty
				temp->setLeftChild(new TreeNode<T>(key));
				temp->getLeftChild()->setParent(temp);
				return;
			}
			temp=root->getLeftChild();// if not empty to further left
		}

		else{
			if (key>temp->getKey()){
				if (temp->getRightChild()==NULL){ // if i should go right and its empty
					temp->setRightChild(new TreeNode<T>(key));
					temp->getRightChild()->setParent(temp);
					return;
				}
				temp=root->getRightChild(); // go further right
			}
		}
	}
}

template<class T>
GTree<T>::GTree() {
	root = 0;
}
/*
template<class T>
GTree<T>::GTree(const GTree<T>& rhs){

}
template<class T>
GTree& GTree<T>:: operator=(const GTree<T>& rhs){}
 */
template<class T>
void GTree<T>::clear() {
	if(!root){ // nothing to clear
		return;
	}
	delete root;
}

template <class T>
TreeNode<T>* GTree<T>::search(TreeNode<T> *root,const T& key)const{
	if(key==root->getKey())
		return this;
	if(root->getKey() < key)
		return search(root->getRightChild(),key);
	return search(root->getLeftChild(),key);
}


template <class T>
TreeNode<T>* GTree<T>::min(TreeNode<T>* root)const{
	if(root==NULL){
		return NULL;
	}
	if(root->getLeftChild()==NULL && root->getRightChild()==NULL){
		return root;
	}
	return min(root->getLeftChild());
}



template <class T>
TreeNode<T>* GTree<T>::max(TreeNode<T>* root)const{
	if(root==NULL){
		return NULL;
	}
	if(root->getLeftChild()==NULL && root->getRightChild()==NULL){
		return root;
	}
	return max(root->getRightChild());
}
template<class T>
int GTree<T>::numOfNodes(TreeNode<T>* root){
	if (!root)
		return 0;
	return 1+numOfNodes(root->getLeftChild())+numOfNodes(root->getRightChild());
}
template <class T>
int GTree<T>::whatIsTheNumOfNodes(){
	return numOfNodes(root);
}
template <class T>
void print(TreeNode<T>* root)const{
	if(root==NULL) //nothing to print
		return;
	print(root->getLeftChild());
	std::cout<< root->getKey() << '\n';
	print(root->getRightChild());
}
template <class T>
void GTree<T>::remove(const T& key, TreeNode<T>* node){
	if (node==NULL)
		return;

	if (key<node->getKey())
		remove(key,node->getLeftChild());
	else if (key>node->getKey())
		remove(key,node->getRightChild());
	else {
		if (!node->getRightChild()&& !node->getLeftChild())
			delete node;
		else if (node->getRightChild()&& !node->getLeftChild()){
			if (node->getParent()->getLeftChild()==node){
				node->getParent()->setLeftChild(node->getRightChild());
			}
			else{
				node->getParent()->setRightChild(node->getRightChild());
			}
			node->getRightChild()->setParent(node->parent);
			node->setRightChild(NULL);
			delete node;
		}
		else if (!node->getRightChild()&& node->getLeftChild()){
			if (node->getParent()->getLeftChild()==node){
				node->getParent()->setLeftChild(node->getLeftChild());
			}
			else{
				node->getParent()->setRightChild(node->getLeftChild());
			}
			node->getLeftChild()->setParent(node->parent);
			node->setLeftChild(NULL);
			delete node;
		}
		else {
			TreeNode<T> *temp = min(node->getRightChild());
			T a=node->getKey();
			node->setKey(temp->getKey());
			delete temp;
		}
	}
}
#endif /* GTREE_H_ */
